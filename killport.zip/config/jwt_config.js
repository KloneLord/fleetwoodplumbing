﻿// config/jwtConfig.js

export const jwtSecret = process.env.JWT_SECRET || 'rRoQREbOIsJGmWAw2UNYHF2JeQVZRAHd';
